<footer class="footer" style="text-align: center;">Group 7 © 2023 - Rental Book </footer>
