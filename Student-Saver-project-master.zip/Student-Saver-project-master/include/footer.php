      <footer class="footer">
          <div class="container">


              <div class="bottom-footer">
                  <div class="row">
                      <div class="col-xs-12 col-sm-3 payment-options color-gray">
                          <h5>Payment Options</h5>
                          <ul>
                              <li>
                                  <a href="#"> <img src="images/Google pay.png" width="20%" alt="Paypal"> </a>
                              </li>
                              <li>
                                  <a href="#"> <img src="images/upi.jpg" width="20%" alt="Mastercard"> </a>
                              </li>
                              <li>
                                  <a href="#"> <img src="images/phone pe.png" width="20%" alt="Maestro"> </a>
                              </li>
                          </ul>
                      </div>
                      <div class="col-xs-12 col-sm-4 address color-gray">
                          <h5>Address</h5>
                          <p><b>SIES GST, Nerul<br>Navi Mumbai</b> </p>
                          <h5>Phone: +91 022-46897825</a></h5>
                      </div>
                      <div class="col-xs-12 col-sm-5 additional-info color-gray">
                          <h5>Addition informations</h5>
                          <p>StudentSaver is a user-friendly website connecting engineering students with affordable second-hand stationery items, lightening the financial load on parents and providing students with access to essential tools for their studies.</p>
                      </div>
                  </div>
              </div>

          </div>
      </footer>
