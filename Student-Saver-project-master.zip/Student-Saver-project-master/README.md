# Student-Saver

# Login Page
![3](https://github.com/user-attachments/assets/1d61b0aa-14aa-434f-9871-9642a6acbf99)

# Home Page
![home Page](https://github.com/user-attachments/assets/7a3a4f13-1736-44d4-9e6b-76debe49abbc)

# How to use
![how to use](https://github.com/user-attachments/assets/112f0709-77bf-4a87-976e-cedbae2375da)

# Book Page
![books_page](https://github.com/user-attachments/assets/60ce76d6-de76-4881-a106-e1628481090f)

# Category
![1](https://github.com/user-attachments/assets/e2fca269-39ae-4567-b672-9a60a82367b7)

# Admin Page
![admin_page](https://github.com/user-attachments/assets/63e8571c-56c9-4535-80a0-ed0dc872c305)

# Add item
![add_item(page)](https://github.com/user-attachments/assets/4059b42c-fb74-4742-a34a-890b4e5a3cf7)

# Order Status
![2](https://github.com/user-attachments/assets/92e9e567-f8f7-4b55-9553-445937216785)
